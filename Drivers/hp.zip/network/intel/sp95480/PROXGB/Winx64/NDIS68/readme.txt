The driver package files in this folder can be used to install drivers for Intel(R) Ethernet 10GbE Adapters and Connections devices on the following Operating Systems:
  *  Microsoft* Windows* 10 Version 1809(x64 Edition)
  *  Microsoft Windows Server* 2019 (x64 Edition)
   
The driver package supports devices based on the following controllers:
  * Intel(R) Ethernet Controller 82598
  * Intel(R) Ethernet Controller 82599
  * Intel(R) Ethernet Controller X520
  * Intel(R) Ethernet Controller X540
  * Intel(R) Ethernet Controller x550
  * Intel(R) Ethernet Controller X552 (Microsoft Windows Server 2019 only)
  * Intel(R) Ethernet Controller X553 (Microsoft Windows Server 2019 only)
