Includes following 64 bit drivers:

00 - Intel Serial IO 30.100.1914.3
00 - Intel Serial IO 30.100.2020.7
00 - Intel Serial IO 30.100.2129.1
00 - Intel Serial IO 30.100.2133.4
00 - Intel Serial IO 30.100.2148.1
00 - Intel Serial IO 30.100.2318.58
00 - Intel Serial IO 30.100.2405.44
00 - Intel Serial IO 30.100.2416.40
00 - Intel Serial IO 30.100.2418.12
05 - AMD_Chipset_4.04.12.1948
05 - AMD_Chipset_5.08.14.509
06 - AMD_USB4_1.0.0.21
20 - RSTe_f6_iaStorS_win8_win10_64 4.5.0.1234
21 - RST 14.8.2.1044
22 - RSTe_f6_iaStorA_win8_win10_64 4.7.0.1068
24 - RSTe_5.4.9.1005_F6_Win10_64
25 - RST 17.9.0.1007
27 - RST 18.36.2.1023
28 - RSTVMD 19.5.0.1037
29 - RST 20.2.3.1018
30 - SmartPqi 63.32.0.64
41 - BayHubTech 1.3.101.1033
80 - AMD_RAID 7.2.0.00057
85 - AMD_RAID_9.3.0.00206
All Docks - Ethernet_Driver, version 2.0.0.1,A,1 
Allied Telesis 1GbE LC Fiber Driver, version 214.0.0.1,E,1 
Allied Telesis 1GbE LC Fiber Driver, version 3.8.4.0,H,1 
Aquantia NIC Driver - Z2 G4 WKS, version 2.2.1.0,G,1  
Broadcom NIC Drivers, version 214.0.0.0,A,1 
Intel I219LM/V Gigabit Ethernet Driver, version 12.18.9.7,A,11 
Intel NIC Driver, version 12.19.0.16,P,2 
Intel NIC Driver, version 12.19.1.37,P,3 
Intel NIC Driver, version 12.19.2.50,P,6
Intel Network Card Drivers, version R26.4,C,1 
Intel Network Card Drivers, version R27.2,A,1 
Intel Network Connections Drivers, version R23.5_517476,A,2 
Realtek Ethernet RTL8111EPH-CG Controller Drivers, version 10.23.1003.2017,A,1 
Realtek Ethernet Driver, version 1166.14.613.2023 
Realtek Local Area Network (LAN) Driver, version 10.31.828.2018,A,6 


HP Manageability website
http://www.hp.com/go/clientmanagement
